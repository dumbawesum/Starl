STARL ANDROID PROJECT

- The original Starl4.html is copied unchanged to app/src/main/assets/Starl4.html.
- The supplied 5507.png is copied unchanged to app/src/main/res/mipmap-nodpi/ic_launcher.png and used as the launcher icon.
- MainActivity loads the local HTML offline in a WebView.

BUILD
1. Open this folder in Android Studio.
2. Let Gradle sync (Android SDK 35 and compatible Gradle/Android Gradle Plugin may be downloaded by Android Studio).
3. Use Build > Build APK(s).

This ZIP contains the Android project source, not a prebuilt APK. The current environment does not have Android build tools installed to compile and verify an APK here.
